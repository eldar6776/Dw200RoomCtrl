export {
  HMAC,
} from './core.js';
